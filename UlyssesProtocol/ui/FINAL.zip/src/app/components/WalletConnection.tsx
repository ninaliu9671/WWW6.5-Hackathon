import { useState, useEffect } from "react";
import { ethers } from "ethers";
import {
  Wallet,
  Activity,
  Send,
  Coins,
  Clock,
  Shield,
  Anchor,
  Ship,
  Crown,
  Sword,
  Star,
  Upload,
  X,
  Info,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { toast } from "sonner";
import { RollingInfo } from "./RollingInfo";
import STAKING_ABI from "../../imports/pasted_text/staking-contract.json";

// Contract address - Replace with your deployed contract address
const STAKING_CONTRACT_ADDRESS =
  "0x8ded19497A7efeC7eb827d2F30002B6E2b531276"; // PLACEHOLDER - UPDATE THIS

// Standard ERC20 ABI for token operations
const ERC20_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
];

// Available wallet symbols
const WALLET_SYMBOLS = [
  { id: "shield", icon: Shield, name: "Shield" },
  { id: "anchor", icon: Anchor, name: "Anchor" },
  { id: "ship", icon: Ship, name: "Ship" },
  { id: "crown", icon: Crown, name: "Crown" },
  { id: "sword", icon: Sword, name: "Sword" },
  { id: "star", icon: Star, name: "Star" },
];

// Available currencies
const CURRENCIES = [
  { id: "btc", name: "Bitcoin", symbol: "₿" },
  { id: "eth", name: "Ethereum", symbol: "Ξ" },
  { id: "sol", name: "Solana", symbol: "◎" },
];

// Avalanche C-Chain network configuration
const AVALANCHE_FUJI = {
  chainId: "0xa869", // 43113 in hex (Fuji Testnet)
  chainName: "Avalanche Fuji Testnet",
  nativeCurrency: {
    name: "AVAX",
    symbol: "AVAX",
    decimals: 18,
  },
  rpcUrls: ["https://api.avax-test.network/ext/bc/C/rpc"],
  blockExplorerUrls: ["https://testnet.snowtrace.io/"],
};

// USDC Token on Avalanche Fuji
const USDC_FUJI_ADDRESS = "0x5425890298aed601595a70AB815c96711a31Bc65"; // USDC on Fuji

export function WalletConnection() {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>("0");
  const [isConnecting, setIsConnecting] = useState(false);
  const [networkName, setNetworkName] = useState<string>("");
  const [selectedSymbol, setSelectedSymbol] = useState<
    string | null
  >(null);
  const [uploadedImage, setUploadedImage] = useState<
    string | null
  >(null);
  const [showSymbolModal, setShowSymbolModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showCheckStakeModal, setShowCheckStakeModal] = useState(false);
  const [checkStakeTokenAddress, setCheckStakeTokenAddress] = useState("");
  const [stakeHistory, setStakeHistory] = useState<any[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [balanceAmount, setBalanceAmount] =
    useState<string>("");
  const [selectedCurrency, setSelectedCurrency] = useState<
    string | null
  >(null);
  const [pledgeTime, setPledgeTime] = useState<number>(3600); // in seconds, default 30 seconds
  const [tokenAddress, setTokenAddress] =
    useState<string>(""); // Changed from targetAddress to tokenAddress - token user promises not to buy
  const [stakeInfo, setStakeInfo] = useState<any>(null);
  const [tokenInfo, setTokenInfo] = useState<{
    symbol: string;
    balance: string;
    allowance: string;
    address: string;
  } | null>(null);
  const [isCheckingToken, setIsCheckingToken] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [pendingReward, setPendingReward] = useState<string | null>(
    null,
  );
  const [isCheckingReward, setIsCheckingReward] = useState(false);
  // Store contract balance info after staking
  const [contractBalance, setContractBalance] = useState<{
    amount: string;
    tokenAddress: string;
  } | null>(null);
  const [unlockTime, setUnlockTime] = useState<number | undefined>(undefined);
  const [expectedReward, setExpectedReward] = useState<string>("0 USDC");

  useEffect(() => {
    checkIfWalletIsConnected();
    // Load persisted stake data from localStorage on mount
    loadPersistedStakeData();
  }, []);

  // Auto-fetch stake info when account AND tokenAddress are both ready
  useEffect(() => {
    if (account && tokenAddress) {
      autoFetchStakeInfo();
    }
  }, [account, tokenAddress]);

  // Persist stake data to localStorage whenever it changes
  useEffect(() => {
    if (account && contractBalance && unlockTime) {
      const stakeData = {
        account,
        contractBalance,
        unlockTime,
        expectedReward,
        tokenAddress: contractBalance.tokenAddress,
      };
      localStorage.setItem('ulysses_stake_data', JSON.stringify(stakeData));
    }
  }, [account, contractBalance, unlockTime, expectedReward]);

  const loadPersistedStakeData = () => {
    try {
      const savedData = localStorage.getItem('ulysses_stake_data');
      console.log('📦 Loading persisted stake data:', savedData);
      if (savedData) {
        const { tokenAddress: savedTokenAddress } = JSON.parse(savedData);
        
        // Only restore the tokenAddress for contract verification
        // Don't restore other data - we'll fetch fresh from blockchain
        if (savedTokenAddress) {
          console.log('✅ Restored tokenAddress from localStorage:', savedTokenAddress);
          setTokenAddress(savedTokenAddress);
        }
      }
    } catch (error) {
      console.error("Error loading persisted stake data:", error);
    }
  };

  const checkIfWalletIsConnected = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const provider = new ethers.BrowserProvider(
          window.ethereum,
        );
        const accounts = await provider.listAccounts();
        if (accounts.length > 0) {
          setAccount(accounts[0].address);
          await updateBalance(accounts[0].address);
          const network = await provider.getNetwork();
          setNetworkName(network.name);
        }
      } catch (error) {
        console.error(
          "Error checking wallet connection:",
          error,
        );
      }
    }
  };

  const updateBalance = async (address: string) => {
    try {
      const provider = new ethers.BrowserProvider(
        window.ethereum,
      );
      const balance = await provider.getBalance(address);
      setBalance(ethers.formatEther(balance));
    } catch (error) {
      console.error("Error fetching balance:", error);
    }
  };

  const connectWallet = async () => {
    if (typeof window.ethereum === "undefined") {
      toast.error("MetaMask not detected", {
        description:
          "Please install MetaMask to use this feature.",
      });
      return;
    }

    setIsConnecting(true);
    try {
      // Request account access
      const provider = new ethers.BrowserProvider(
        window.ethereum,
      );
      const accounts = await provider.send(
        "eth_requestAccounts",
        [],
      );

      if (accounts.length > 0) {
        setAccount(accounts[0]);
        await updateBalance(accounts[0]);

        // Try to switch to Avalanche network
        try {
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: AVALANCHE_FUJI.chainId }],
          });
        } catch (switchError: any) {
          // If network doesn't exist, add it
          if (switchError.code === 4902) {
            try {
              await window.ethereum.request({
                method: "wallet_addEthereumChain",
                params: [AVALANCHE_FUJI],
              });
            } catch (addError) {
              console.error(
                "Error adding Avalanche network:",
                addError,
              );
            }
          }
        }

        const network = await provider.getNetwork();
        setNetworkName(network.name);

        toast.success("Wallet Connected", {
          description: `Connected to ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`,
        });

        // Check if there's a saved token address in localStorage
        const savedData = localStorage.getItem('ulysses_stake_data');
        if (savedData) {
          try {
            const { tokenAddress: savedTokenAddress } = JSON.parse(savedData);
            if (savedTokenAddress) {
              // Auto-populate the check modal with saved address
              setCheckStakeTokenAddress(savedTokenAddress);
            }
          } catch (e) {
            console.error('Error parsing saved data:', e);
          }
        }

        // Show the check stake modal after successful connection
        setTimeout(() => {
          setShowCheckStakeModal(true);
          // Automatically fetch stake history when modal opens
          fetchStakeHistory(accounts[0]);
        }, 500);
      }
    } catch (error: any) {
      console.error("Error connecting wallet:", error);
      toast.error("Connection Failed", {
        description:
          error.message || "Failed to connect wallet",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const checkBalance = async () => {
    if (!account) {
      toast.error("No wallet connected", {
        description: "Please connect your wallet first.",
      });
      return;
    }

    try {
      await updateBalance(account);
      toast.success("Balance Updated", {
        description: `Current balance: ${parseFloat(balance).toFixed(4)} AVAX`,
      });
    } catch (error: any) {
      toast.error("Error fetching balance", {
        description: error.message || "Failed to fetch balance",
      });
    }
  };

  const selectCurrency = async () => {
    if (!account) {
      toast.error("No wallet connected", {
        description: "Please connect your wallet first.",
      });
      return;
    }

    // Demo: Show available currencies
    toast.info("Select Currency", {
      description:
        "Available: AVAX, USDC, USDT. Implement currency selection logic here.",
      duration: 5000,
    });
  };

  const selectPledgeTime = async () => {
    if (!account) {
      toast.error("No wallet connected", {
        description: "Please connect your wallet first.",
      });
      return;
    }

    // Demo: Show pledge time options
    toast.info("Select Pledge Time", {
      description:
        "Available periods: 7 days, 30 days, 90 days, 180 days. Implement pledge time selection here.",
      duration: 5000,
    });
  };

  const sendTransaction = async () => {
    if (!account) {
      toast.error("No wallet connected", {
        description: "Please connect your wallet first.",
      });
      return;
    }

    // This is a demo - in production, you'd show a form for recipient and amount
    toast.info("Transaction Demo", {
      description:
        "This would open a transaction form. Implement your specific transaction logic here.",
      duration: 5000,
    });

    // Example transaction code (commented out for safety):
    /*
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      
      const tx = await signer.sendTransaction({
        to: 'RECIPIENT_ADDRESS_HERE',
        value: ethers.parseEther('0.01'), // 0.01 AVAX
      });
      
      toast.success('Transaction Sent', {
        description: `Transaction hash: ${tx.hash}`,
      });
      
      await tx.wait();
      toast.success('Transaction Confirmed');
      await updateBalance(account);
    } catch (error: any) {
      toast.error('Transaction Failed', {
        description: error.message,
      });
    }
    */
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatPledgeTime = (seconds: number) => {
    if (seconds < 60) {
      return `${seconds} seconds`;
    } else if (seconds < 3600) {
      return `${Math.floor(seconds / 60)} minutes`;
    } else if (seconds < 86400) {
      return `${Math.floor(seconds / 3600)} hours`;
    } else {
      return `${Math.floor(seconds / 86400)} days`;
    }
  };

  const handleSaveInfo = async () => {
    if (
      !balanceAmount ||
      !pledgeTime ||
      !tokenAddress
    ) {
      toast.error("Incomplete Information", {
        description:
          "Please fill in all fields",
      });
      return;
    }

    try {
      // Step 1: Check token info
      toast.info("Step 1/3: Checking token info...", {
        description: "Retrieving token information from contract",
      });

      const stakingContract = await getStakingContract();
      const stakingTokenAddress = await stakingContract.stakingToken();

      const provider = new ethers.BrowserProvider(window.ethereum);
      const tokenContract = new ethers.Contract(
        stakingTokenAddress,
        ERC20_ABI,
        provider,
      );

      const [symbol, decimals, balance, allowance] =
        await Promise.all([
          tokenContract.symbol(),
          tokenContract.decimals(),
          tokenContract.balanceOf(account),
          tokenContract.allowance(
            account,
            STAKING_CONTRACT_ADDRESS,
          ),
        ]);

      const formattedBalance = ethers.formatUnits(balance, decimals);
      const formattedAllowance = ethers.formatUnits(allowance, decimals);

      setTokenInfo({
        symbol,
        balance: formattedBalance,
        allowance: formattedAllowance,
        address: stakingTokenAddress,
      });

      toast.success("Token info retrieved", {
        description: `Token: ${symbol}, Your balance: ${parseFloat(formattedBalance).toFixed(4)}`,
        duration: 3000,
      });

      // Step 2: Check if approval is needed
      const amountToStake = ethers.parseUnits(balanceAmount, decimals);
      const currentAllowance = allowance;

      if (currentAllowance < amountToStake) {
        toast.info("Step 2/3: Approval needed...", {
          description: "Please approve tokens in MetaMask",
        });

        const signer = await provider.getSigner();
        const tokenContractWithSigner = new ethers.Contract(
          stakingTokenAddress,
          ERC20_ABI,
          signer,
        );

        const approveTx = await tokenContractWithSigner.approve(
          STAKING_CONTRACT_ADDRESS,
          amountToStake,
        );

        toast.info("Approval transaction sent", {
          description: "Waiting for confirmation...",
        });

        await approveTx.wait();

        toast.success("Tokens approved!", {
          description: `Approved ${balanceAmount} ${symbol} for staking`,
          duration: 3000,
        });

        // Update token info with new allowance
        const newAllowance = await tokenContract.allowance(
          account,
          STAKING_CONTRACT_ADDRESS,
        );
        setTokenInfo({
          symbol,
          balance: formattedBalance,
          allowance: ethers.formatUnits(newAllowance, decimals),
          address: stakingTokenAddress,
        });
      } else {
        toast.success("Step 2/3: Already approved", {
          description: "Sufficient allowance detected",
          duration: 2000,
        });
      }

      toast.success("Setup Complete!", {
        description: `Ready to stake ${balanceAmount} tokens. Click 'Stake Tokens' to proceed.`,
        duration: 5000,
      });

      setShowInfoModal(false);
    } catch (error: any) {
      console.error("Error in setup process:", error);
      toast.error("Setup Failed", {
        description: error.message || "Failed to complete setup",
      });
    }
  };

  const getStakingContract = async () => {
    if (typeof window.ethereum === "undefined") {
      throw new Error("MetaMask not detected");
    }

    const provider = new ethers.BrowserProvider(
      window.ethereum,
    );
    const signer = await provider.getSigner();
    return new ethers.Contract(
      STAKING_CONTRACT_ADDRESS,
      STAKING_ABI,
      signer,
    );
  };

  const checkTokenInfo = async () => {
    if (!account) {
      toast.error("No wallet connected", {
        description: "Please connect your wallet first",
      });
      return;
    }

    setIsCheckingToken(true);
    try {
      const stakingContract = await getStakingContract();

      // Get the staking token address from the contract
      const tokenAddress = await stakingContract.stakingToken();

      const provider = new ethers.BrowserProvider(
        window.ethereum,
      );
      const tokenContract = new ethers.Contract(
        tokenAddress,
        ERC20_ABI,
        provider,
      );

      // Get token info
      const [symbol, decimals, balance, allowance] =
        await Promise.all([
          tokenContract.symbol(),
          tokenContract.decimals(),
          tokenContract.balanceOf(account),
          tokenContract.allowance(
            account,
            STAKING_CONTRACT_ADDRESS,
          ),
        ]);

      const formattedBalance = ethers.formatUnits(
        balance,
        decimals,
      );
      const formattedAllowance = ethers.formatUnits(
        allowance,
        decimals,
      );

      setTokenInfo({
        symbol,
        balance: formattedBalance,
        allowance: formattedAllowance,
        address: tokenAddress,
      });

      toast.success("Token Info Retrieved", {
        description: `Token: ${symbol}, Balance: ${parseFloat(formattedBalance).toFixed(4)}, Approved: ${parseFloat(formattedAllowance).toFixed(4)}`,
        duration: 7000,
      });
    } catch (error: any) {
      console.error("Error checking token:", error);
      toast.error("Failed to Check Token", {
        description:
          error.message ||
          "Could not retrieve token information. Make sure the staking contract address is correct.",
      });
    } finally {
      setIsCheckingToken(false);
    }
  };

  const approveTokens = async () => {
    if (!account || !tokenInfo) {
      toast.error("Token info not loaded", {
        description: "Please check token info first",
      });
      return;
    }

    if (!balanceAmount) {
      toast.error("No amount specified", {
        description:
          "Please enter an amount in the Enter Information modal",
      });
      return;
    }

    setIsApproving(true);
    try {
      const provider = new ethers.BrowserProvider(
        window.ethereum,
      );
      const signer = await provider.getSigner();
      const tokenContract = new ethers.Contract(
        tokenInfo.address,
        ERC20_ABI,
        signer,
      );

      // Approve exact amount or use max for unlimited
      const amountToApprove = ethers.parseEther(balanceAmount);

      toast.info("Approval Request", {
        description:
          "Please confirm the approval transaction in MetaMask",
      });

      const tx = await tokenContract.approve(
        STAKING_CONTRACT_ADDRESS,
        amountToApprove,
      );

      toast.success("Approval Transaction Sent", {
        description: `Transaction hash: ${tx.hash}`,
      });

      await tx.wait();

      toast.success("Approval Successful", {
        description: `Approved ${balanceAmount} ${tokenInfo.symbol} for staking`,
        duration: 7000,
      });

      // Refresh token info
      await checkTokenInfo();
    } catch (error: any) {
      console.error("Error approving tokens:", error);
      toast.error("Approval Failed", {
        description:
          error.message || "Failed to approve tokens",
      });
    } finally {
      setIsApproving(false);
    }
  };

  const checkStakeInfo = async () => {
    if (!account) {
      toast.error("Missing Information", {
        description: "Please connect your wallet",
      });
      return;
    }

    // Use tokenAddress from contractBalance if available, otherwise use the input field
    const addressToCheck = contractBalance?.tokenAddress || tokenAddress;

    if (!addressToCheck) {
      toast.error("Missing Information", {
        description:
          "Please enter token address in Enter Information or stake first",
      });
      return;
    }

    try {
      const contract = await getStakingContract();
      const stake = await contract.userStakes(
        account,
        addressToCheck,
      );

      if (!stake.isActive || stake.amount === 0n) {
        toast.info("No Active Stake", {
          description: "You don't have an active stake for this token",
          duration: 5000,
        });
        return;
      }

      const formattedAmount = ethers.formatUnits(stake.amount, 6); // USDC has 6 decimals

      setStakeInfo({
        amount: formattedAmount,
        weight: stake.weight.toString(),
        startTime: new Date(
          Number(stake.startTime) * 1000,
        ).toLocaleString(),
        unlockTime: new Date(
          Number(stake.unlockTime) * 1000,
        ).toLocaleString(),
        isActive: stake.isActive,
      });

      const now = Math.floor(Date.now() / 1000);
      const timeRemaining = Number(stake.unlockTime) - now;
      const timeRemainingFormatted = timeRemaining > 0 
        ? formatPledgeTime(timeRemaining)
        : "Unlocked!";

      toast.success("Stake Status Retrieved", {
        description: `Staked: ${formattedAmount} USDC\nToken Prohibited: ${formatAddress(addressToCheck)}\nUnlock: ${new Date(Number(stake.unlockTime) * 1000).toLocaleString()}\nTime Remaining: ${timeRemainingFormatted}`,
        duration: 10000,
      });
    } catch (error: any) {
      console.error("Error checking stake:", error);
      toast.error("Failed to Check Stake", {
        description:
          error.message ||
          "Could not retrieve stake information",
      });
    }
  };

  const autoFetchStakeInfo = async () => {
    if (!account) {
      console.log('⚠️ autoFetchStakeInfo: No account connected');
      return;
    }

    console.log('🔍 autoFetchStakeInfo called with:', { account, tokenAddress });

    try {
      const contract = await getStakingContract();
      
      // Get contract status information
      const [totalWeight, accRewardPerWeight, stakingTokenAddress, watcherAddress, ownerAddress] = await Promise.all([
        contract.totalWeight(),
        contract.accRewardPerWeight(),
        contract.stakingToken(),
        contract.watcher(),
        contract.owner(),
      ]);

      // Display contract status
      console.log("📊 Contract Status:");
      console.log("  - Total Weight:", totalWeight.toString());
      console.log("  - Accumulated Reward Per Weight:", accRewardPerWeight.toString());
      console.log("  - Staking Token:", stakingTokenAddress);
      console.log("  - Watcher Address:", watcherAddress);
      console.log("  - Owner Address:", ownerAddress);

      toast.success("Contract Status Retrieved", {
        description: `Total Weight: ${totalWeight.toString()}\nStaking Token: ${formatAddress(stakingTokenAddress)}\nWatcher: ${formatAddress(watcherAddress)}`,
        duration: 7000,
      });

      // Try to find user's staked tokens from blockchain events
      console.log('🔎 Searching for user stakes from blockchain events...');
      
      let tokenAddressToCheck = tokenAddress;
      
      // If no tokenAddress in state, query blockchain events to find it
      if (!tokenAddressToCheck) {
        try {
          const provider = new ethers.BrowserProvider(window.ethereum);
          const contractWithProvider = new ethers.Contract(
            STAKING_CONTRACT_ADDRESS,
            STAKING_ABI,
            provider,
          );
          
          // Query past Staked events for this user
          const filter = contractWithProvider.filters.Staked(account, null);
          const events = await contractWithProvider.queryFilter(filter, -10000); // Last ~10000 blocks
          
          console.log(`📜 Found ${events.length} staking events for user`);
          
          // Check each staked token to see if still active
          for (const event of events.reverse()) { // Check most recent first
            const targetToken = event.args?.[1]; // target is the second indexed parameter
            if (targetToken) {
              console.log(`🔍 Checking stake for token: ${targetToken}`);
              const stake = await contract.userStakes(account, targetToken);
              
              if (stake.isActive && stake.amount > 0n) {
                console.log(`✅ Found active stake for token: ${targetToken}`);
                tokenAddressToCheck = targetToken;
                setTokenAddress(targetToken); // Update state
                break;
              }
            }
          }
          
          if (!tokenAddressToCheck) {
            console.log('⚠️ No active stakes found from events');
            return;
          }
        } catch (eventError) {
          console.log('⚠️ Could not query events, falling back to localStorage:', eventError);
          return;
        }
      }

      // Now check the stake with the found token address
      if (tokenAddressToCheck) {
        console.log('🔎 Checking stake for tokenAddress:', tokenAddressToCheck);
        const stake = await contract.userStakes(
          account,
          tokenAddressToCheck,
        );

        console.log('📋 Stake result:', {
          isActive: stake.isActive,
          amount: stake.amount.toString(),
          unlockTime: Number(stake.unlockTime),
          weight: stake.weight.toString(),
        });

        // Check if stake is active
        if (stake.isActive && stake.amount > 0n) {
          console.log('✅ Active stake found! Setting state...');
          const formattedAmount = ethers.formatUnits(stake.amount, 6); // USDC has 6 decimals
          
          setContractBalance({
            amount: formattedAmount,
            tokenAddress: tokenAddressToCheck,
          });

          setUnlockTime(Number(stake.unlockTime));
          
          // Calculate expected reward
          const pendingReward = await contract.getPendingReward(account, tokenAddressToCheck);
          const formattedReward = ethers.formatUnits(pendingReward, 6);
          setExpectedReward(`${parseFloat(formattedReward).toFixed(4)} USDC`);

          setStakeInfo({
            amount: formattedAmount,
            weight: stake.weight.toString(),
            startTime: new Date(
              Number(stake.startTime) * 1000,
            ).toLocaleString(),
            unlockTime: new Date(
              Number(stake.unlockTime) * 1000,
            ).toLocaleString(),
            isActive: stake.isActive,
          });

          console.log('✅ State updated successfully! Rolling info should now appear.');

          toast.success("User Stake Found!", {
            description: `Active stake: ${formattedAmount} USDC\nPending rewards: ${formattedReward} USDC\nUnlock: ${new Date(Number(stake.unlockTime) * 1000).toLocaleString()}`,
            duration: 7000,
          });
        } else {
          console.log('⚠️ Stake not active or amount is 0');
        }
      } else {
        console.log('⚠️ No tokenAddress available to check stakes');
      }
    } catch (error: any) {
      // Silent fail - user may not have staked yet
      console.log("❌ Error fetching contract status:", error.message);
      console.error('Full error:', error);
    }
  };

  const stakeTokens = async () => {
    if (
      !account ||
      !balanceAmount ||
      !tokenAddress ||
      !pledgeTime
    ) {
      toast.error("Missing Information", {
        description:
          "Please fill in all required fields via Enter Information button",
      });
      return;
    }

    try {
      const contract = await getStakingContract();

      // USDC uses 6 decimals
      const amountInWei = ethers.parseUnits(balanceAmount, 6);

      // Important: USDC tokens will be transferred to STAKING_CONTRACT_ADDRESS
      // The tokenAddress parameter is the token user promises NOT to buy (sent to watcher for monitoring)
      toast.info("Initiating Stake", {
        description:
          `Transferring ${balanceAmount} USDC to contract ${formatAddress(STAKING_CONTRACT_ADDRESS)}...`,
      });

      const tx = await contract.stake(
        amountInWei,
        pledgeTime,
        tokenAddress, // Token address to watch (for slashing if user buys it)
      );
      console.log("📨 stake tx hash:", tx.hash);

      toast.success("Transaction Sent", {
        description: `Staking ${balanceAmount} USDC to ${formatAddress(STAKING_CONTRACT_ADDRESS)}. Watcher monitoring ${formatAddress(tokenAddress)}`,
        duration: 5000,
      });

      const receipt = await tx.wait();

      console.log("📦 stake transaction block:", receipt.blockNumber);
      console.log("📦 full receipt:", receipt);

      toast.success("Stake Successful", {
        description: `${balanceAmount} USDC transferred to contract. Watcher monitoring ${formatAddress(tokenAddress)} for ${formatPledgeTime(pledgeTime)}`,
        duration: 7000,
      });

      await updateBalance(account);
      // Store contract balance info - USDC was transferred to STAKING_CONTRACT_ADDRESS
      setContractBalance({
        amount: balanceAmount,
        tokenAddress: tokenAddress, // Token being watched (that user promises not to buy)
      });

      // Set unlock time for rolling frame
      const calculatedUnlockTime = Math.floor(Date.now() / 1000) + pledgeTime;
      setUnlockTime(calculatedUnlockTime);
      setExpectedReward("0 USDC"); // This would be calculated from contract in real implementation

      // Emit contract info update for rolling frame
      const contractInfoEvent = new CustomEvent("contractInfoUpdate", {
        detail: {
          unlockTime: calculatedUnlockTime,
          expectedReward: "0 USDC",
        },
      });
      window.dispatchEvent(contractInfoEvent);
    } catch (error: any) {
      console.error("Error staking:", error);
      toast.error("Stake Failed", {
        description:
          error.message ||
          "Failed to stake tokens. Make sure you have approved the contract to spend your tokens.",
      });
    }
  };

  const checkPendingReward = async () => {
    if (!account) {
      toast.error("Missing Information", {
        description: "Please connect your wallet",
      });
      return;
    }

    // Use tokenAddress from contractBalance if available, otherwise use the input field
    const addressToCheck = contractBalance?.tokenAddress || tokenAddress;

    if (!addressToCheck) {
      toast.error("Missing Information", {
        description:
          "Please enter token address in Enter Information or stake first",
      });
      return;
    }

    setIsCheckingReward(true);
    try {
      const contract = await getStakingContract();

      const reward = await contract.getPendingReward(
        account,
        addressToCheck,
      );

      const formattedReward = ethers.formatUnits(reward, 6); // USDC has 6 decimals
      setPendingReward(formattedReward);

      if (reward === 0n) {
        toast.info("No Pending Rewards", {
          description: "You currently have no rewards to claim",
          duration: 5000,
        });
      } else {
        toast.success("Pending Reward Retrieved", {
          description: `You have ${parseFloat(formattedReward).toFixed(4)} USDC pending\nToken Prohibited: ${formatAddress(addressToCheck)}`,
          duration: 7000,
        });
      }
    } catch (error: any) {
      console.error("Error checking pending reward:", error);
      toast.error("Failed to Check Reward", {
        description:
          error.message ||
          "Could not retrieve pending reward information",
      });
    } finally {
      setIsCheckingReward(false);
    }
  };

  const extractRewards = async () => {
    if (!account) {
      toast.error("Wallet Not Connected", {
        description: "Please connect your wallet first",
      });
      return;
    }

    // Use tokenAddress from contractBalance if available
    const addressToCheck = contractBalance?.tokenAddress || tokenAddress;

    if (!addressToCheck) {
      toast.error("No Active Stake", {
        description: "You don't have any staked tokens to extract",
      });
      return;
    }

    try {
      const contract = await getStakingContract();

      // Check pending rewards first
      const pendingRewardAmount = await contract.getPendingReward(
        account,
        addressToCheck,
      );

      const formattedReward = ethers.formatUnits(pendingRewardAmount, 6);

      // Check if user has any stake
      const stake = await contract.userStakes(account, addressToCheck);
      
      if (!stake.isActive || stake.amount === 0n) {
        toast.error("No Active Stake", {
          description: "You don't have any active stakes to extract from",
        });
        return;
      }

      const formattedStake = ethers.formatUnits(stake.amount, 6);

      // Check if lock period has ended
      const now = Math.floor(Date.now() / 1000);
      const isUnlocked = Number(stake.unlockTime) <= now;

      if (!isUnlocked) {
        const timeRemaining = Number(stake.unlockTime) - now;
        toast.error("Stake Still Locked", {
          description: `Your stake will unlock in ${formatPledgeTime(timeRemaining)}. You can only extract after the lock period ends.`,
          duration: 7000,
        });
        return;
      }

      toast.info("Initiating Extraction", {
        description: `Extracting ${formattedStake} USDC staked + ${formattedReward} USDC rewards...`,
      });

      // Call the claim function (which extracts stake + rewards)
      const tx = await contract.claim(addressToCheck);

      toast.success("Transaction Sent", {
        description: `Extraction transaction hash: ${tx.hash}`,
        duration: 5000,
      });

      await tx.wait();

      toast.success("✨ Extraction Successful!", {
        description: `Successfully extracted ${formattedStake} USDC stake + ${formattedReward} USDC rewards to your wallet`,
        duration: 10000,
      });

      // Reset state and clear localStorage
      setContractBalance(null);
      setUnlockTime(undefined);
      setExpectedReward("0 USDC");
      setPendingReward(null);
      setStakeInfo(null);
      localStorage.removeItem('ulysses_stake_data');
      
      // Update balance
      await updateBalance(account);
    } catch (error: any) {
      console.error("Error extracting rewards:", error);
      toast.error("Extraction Failed", {
        description: error.message || "Failed to extract tokens and rewards from contract",
        duration: 7000,
      });
    }
  };

  const handleImageUpload = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        // 5MB limit
        toast.error("Image too large", {
          description:
            "Please select an image smaller than 5MB",
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setSelectedSymbol("uploaded");
        setShowSymbolModal(false);
        toast.success("Image uploaded", {
          description: "Your custom symbol has been set",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectSymbol = (symbolId: string) => {
    setSelectedSymbol(symbolId);
    setUploadedImage(null);
    setShowSymbolModal(false);
    toast.success("Symbol selected", {
      description: `You selected ${WALLET_SYMBOLS.find((s) => s.id === symbolId)?.name}`,
    });
  };

  const renderSelectedSymbol = () => {
    if (uploadedImage) {
      return (
        <img
          src={uploadedImage}
          alt="Custom symbol"
          className="w-8 h-8 rounded-full object-cover"
        />
      );
    }
    if (selectedSymbol) {
      const symbol = WALLET_SYMBOLS.find(
        (s) => s.id === selectedSymbol,
      );
      if (symbol) {
        const IconComponent = symbol.icon;
        return (
          <IconComponent className="w-8 h-8 text-yellow-400" />
        );
      }
    }
    return null;
  };

  const renderSelectedSymbolLarge = () => {
    if (uploadedImage) {
      return (
        <img
          src={uploadedImage}
          alt="Custom symbol"
          className="w-16 h-16 rounded-full object-cover mx-auto mb-4"
        />
      );
    }
    if (selectedSymbol) {
      const symbol = WALLET_SYMBOLS.find(
        (s) => s.id === selectedSymbol,
      );
      if (symbol) {
        const IconComponent = symbol.icon;
        return (
          <IconComponent className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
        );
      }
    }
    return null;
  };

  const fetchStakeHistory = async (userAddress: string) => {
    setIsLoadingHistory(true);
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const contractWithProvider = new ethers.Contract(
        STAKING_CONTRACT_ADDRESS,
        STAKING_ABI,
        provider,
      );
      
      // Query past Staked events for this user
      const filter = contractWithProvider.filters.Staked(userAddress, null);
      const events = await contractWithProvider.queryFilter(filter, -10000); // Last ~10000 blocks
      
      console.log(`📜 Found ${events.length} staking events for user`);
      
      // Process each event to get stake details
      const stakeDetails = await Promise.all(events.map(async (event) => {
        const targetToken = event.args?.[1]; // target is the second indexed parameter
        if (targetToken) {
          console.log(`🔍 Checking stake for token: ${targetToken}`);
          const stake = await contractWithProvider.userStakes(userAddress, targetToken);
          
          const formattedAmount = ethers.formatUnits(stake.amount, 6); // USDC has 6 decimals
          const formattedReward = ethers.formatUnits(stake.pendingReward, 6);
          
          return {
            tokenAddress: targetToken,
            amount: formattedAmount,
            reward: formattedReward,
            startTime: new Date(Number(stake.startTime) * 1000).toLocaleString(),
            unlockTime: new Date(Number(stake.unlockTime) * 1000).toLocaleString(),
            isActive: stake.isActive,
          };
        }
        return null;
      }));
      
      // Filter out any null entries
      const filteredStakeDetails = stakeDetails.filter((detail) => detail !== null) as any[];
      
      setStakeHistory(filteredStakeDetails);
      console.log('📊 Stake History:', filteredStakeDetails);
    } catch (error) {
      console.error('Error fetching stake history:', error);
      toast.error("Failed to Fetch Stake History", {
        description:
          error.message ||
          "Could not retrieve stake history information",
      });
    } finally {
      setIsLoadingHistory(false);
    }
  };

  return (
    <div className="space-y-6">
      {account ? (
        <Card className="p-6 bg-white/10 backdrop-blur-lg border-white/20">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {selectedSymbol && renderSelectedSymbol()}
                <div>
                  <p className="text-sm text-white/70">
                    Connected Wallet
                  </p>
                  <p className="text-lg font-mono text-white">
                    {formatAddress(account)}
                  </p>
                </div>
              </div>
              <div className="h-3 w-3 bg-green-400 rounded-full animate-pulse" />
            </div>

            <div className="pt-4 border-t border-white/10">
              <p className="text-sm text-white/70">
                Token in Contract
              </p>
              {contractBalance ? (
                <div className="space-y-2">
                  <p className="text-2xl text-white">
                    {contractBalance.amount} USDC
                  </p>
                  <div className="pt-2 border-t border-white/10">
                    <p className="text-xs text-white/50">
                      Token Prohibited
                    </p>
                    <p className="text-sm font-mono text-white/80">
                      {formatAddress(contractBalance.tokenAddress)}
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-xl text-white/60">
                  No tokens staked yet
                </p>
              )}
            </div>

            {networkName && (
              <div className="pt-2">
                <p className="text-xs text-white/60">
                  Network: {networkName}
                </p>
              </div>
            )}
          </div>
        </Card>
      ) : (
        <div className="space-y-6">
          {!selectedSymbol ? (
            <div className="text-center py-4">
              <p className="text-white/90 mb-2 text-lg font-semibold">
                Step 1: Choose Your Symbol
              </p>
              <p className="text-white/60 mb-6 text-sm max-w-md mx-auto">
                Select a personal symbol that represents your commitment to self-control
              </p>
              <Button
                onClick={() => setShowSymbolModal(true)}
                size="lg"
                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white border-0"
              >
                <Upload className="mr-2 h-5 w-5" />
                Select Symbol
              </Button>
            </div>
          ) : (
            <div className="text-center py-8">
              {renderSelectedSymbolLarge()}
              <p className="text-white/70 mb-2">
                {uploadedImage
                  ? "Custom Image"
                  : `Symbol: ${WALLET_SYMBOLS.find((s) => s.id === selectedSymbol)?.name}`}
              </p>
              <Button
                onClick={() => {
                  setSelectedSymbol(null);
                  setUploadedImage(null);
                }}
                variant="ghost"
                size="sm"
                className="text-white/50 hover:text-white/70"
              >
                Change Symbol
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Check Previous Stake Modal */}
      {showCheckStakeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="relative bg-gradient-to-br from-gray-900/95 to-gray-800/95 backdrop-blur-xl rounded-2xl p-6 max-w-md w-full border border-white/20 shadow-2xl">
            <button
              onClick={() => setShowCheckStakeModal(false)}
              className="absolute top-4 right-4 text-white/50 hover:text-white/90 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <h3 className="text-xl text-white mb-4 flex items-center gap-2">
              <Info className="w-6 h-6 text-blue-400" />
              {isLoadingHistory ? "Loading Stake History..." : "Your Stake History"}
            </h3>

            {isLoadingHistory ? (
              <div className="flex flex-col items-center justify-center py-8 mb-4">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mb-4"></div>
                <p className="text-white/60 text-sm">Querying blockchain...</p>
              </div>
            ) : stakeHistory.length > 0 ? (
              <div className="space-y-3 mb-4 max-h-96 overflow-y-auto">
                {stakeHistory.map((stake, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setTokenAddress(stake.tokenAddress);
                      setShowCheckStakeModal(false);
                      toast.success("Stake Selected", {
                        description: `Loading stake for ${formatAddress(stake.tokenAddress)}`,
                      });
                    }}
                    className={`w-full p-4 rounded-lg border transition-all hover:scale-[1.02] ${
                      stake.isActive
                        ? 'bg-green-500/10 border-green-400/30 hover:border-green-400/50'
                        : 'bg-white/5 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {stake.isActive ? (
                          <CheckCircle2 className="w-5 h-5 text-green-400" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-white/40" />
                        )}
                        <span className={`text-sm font-semibold ${stake.isActive ? 'text-green-400' : 'text-white/60'}`}>
                          {stake.isActive ? 'Active' : 'Completed'}
                        </span>
                      </div>
                      <span className="text-white font-bold">
                        {parseFloat(stake.amount).toFixed(2)} USDC
                      </span>
                    </div>
                    <div className="text-left space-y-1">
                      <p className="text-xs text-white/50">Token Prohibited</p>
                      <p className="text-xs font-mono text-white/80 mb-2">
                        {formatAddress(stake.tokenAddress)}
                      </p>
                      <div className="flex justify-between text-xs text-white/60">
                        <span>Unlock: {new Date(stake.unlockTime).toLocaleDateString()}</span>
                        {stake.isActive && (
                          <span className="text-green-400">→ Click to load</span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 mb-4">
                <AlertCircle className="w-12 h-12 text-white/30 mx-auto mb-3" />
                <p className="text-white/60 text-sm">No stake history found</p>
                <p className="text-white/40 text-xs mt-1">Enter a token address below to check manually</p>
              </div>
            )}

            <p className="text-white/70 text-sm mb-4">
              {stakeHistory.length > 0 ? 'Or enter' : 'Enter'} the prohibited token address to check a specific stake:
            </p>

            <div className="space-y-4">
              <div>
                <label className="text-white/70 text-sm mb-2 block">
                  Token Prohibited Address
                </label>
                <input
                  type="text"
                  placeholder="0x..."
                  value={checkStakeTokenAddress}
                  onChange={(e) => setCheckStakeTokenAddress(e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-400/50 font-mono text-sm"
                />
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={async () => {
                    if (checkStakeTokenAddress) {
                      setTokenAddress(checkStakeTokenAddress);
                      setShowCheckStakeModal(false);
                      toast.info("Checking stake...", {
                        description: "Querying blockchain for your stake",
                      });
                    } else {
                      toast.error("Missing Address", {
                        description: "Please enter a token address",
                      });
                    }
                  }}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white border-0"
                >
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  Check Stake
                </Button>

                <Button
                  onClick={() => {
                    setShowCheckStakeModal(false);
                  }}
                  variant="outline"
                  className="flex-1 bg-white/10 hover:bg-white/20 text-white border-white/30"
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Symbol Selection Modal */}
      {showSymbolModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="relative bg-gradient-to-br from-gray-900/95 to-gray-800/95 backdrop-blur-xl rounded-2xl p-6 max-w-lg w-full border border-white/20 shadow-2xl">
            <button
              onClick={() => setShowSymbolModal(false)}
              className="absolute top-4 right-4 text-white/50 hover:text-white/90 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <h3 className="text-2xl text-white mb-6">
              Choose Your Symbol
            </h3>

            <div className="space-y-6">
              {/* Predefined Symbols */}
              <div>
                <p className="text-white/70 mb-4 text-sm">
                  Select from symbols:
                </p>
                <div className="grid grid-cols-3 gap-3">
                  {WALLET_SYMBOLS.map((symbol) => {
                    const IconComponent = symbol.icon;
                    return (
                      <button
                        key={symbol.id}
                        onClick={() =>
                          handleSelectSymbol(symbol.id)
                        }
                        className="group bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/20 hover:border-yellow-400/50 transition-all duration-300 flex flex-col items-center gap-2"
                      >
                        <IconComponent className="w-10 h-10 text-white/70 group-hover:text-yellow-400 transition-colors" />
                        <span className="text-xs text-white/70 group-hover:text-white">
                          {symbol.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Upload Custom Image */}
              <div className="pt-4 border-t border-white/20">
                <p className="text-white/70 mb-4 text-sm">
                  Or upload your own image:
                </p>
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-white/30 rounded-lg cursor-pointer bg-white/5 hover:bg-white/10 transition-all">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className="w-8 h-8 mb-2 text-white/60" />
                    <p className="text-sm text-white/60">
                      Click to upload image
                    </p>
                    <p className="text-xs text-white/40 mt-1">
                      PNG, JPG up to 5MB
                    </p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Enter Information Modal */}
      {showInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="relative bg-gradient-to-br from-gray-900/95 to-gray-800/95 backdrop-blur-xl rounded-2xl p-6 max-w-lg w-full border border-white/20 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowInfoModal(false)}
              className="absolute top-4 right-4 text-white/50 hover:text-white/90 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <h3 className="text-2xl text-white mb-6">
              Enter Information
            </h3>

            <div className="space-y-6">
              {/* Check Balance / Amount Input */}
              <div>
                <label className="text-white/70 text-sm mb-2 block">
                  <Activity className="w-4 h-4 inline mr-2" />
                  Balance Amount
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="Enter amount"
                  value={balanceAmount}
                  onChange={(e) =>
                    setBalanceAmount(e.target.value)
                  }
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-yellow-400/50"
                />
              </div>

              {/* Token Address Input */}
              <div>
                <label className="text-white/70 text-sm mb-2 block">
                  <Send className="w-4 h-4 inline mr-2" />
                  Token Prohibited
                </label>
                <input
                  type="text"
                  placeholder="0x..."
                  value={tokenAddress}
                  onChange={(e) =>
                    setTokenAddress(e.target.value)
                  }
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-yellow-400/50 font-mono text-sm"
                />
                <p className="text-xs text-white/40 mt-2">
                  Note: Your USDC will be staked to the contract. This token address will be monitored by the watcher for slashing.
                </p>
              </div>

              {/* Select Pledge Time */}
              <div>
                <label className="text-white/70 text-sm mb-2 block">
                  <Clock className="w-4 h-4 inline mr-2" />
                  Select Pledge Time:{" "}
                  {formatPledgeTime(pledgeTime)}
                </label>
                <input
                  type="range"
                  min="3600"
                  max="259200"
                  step="1"
                  value={pledgeTime}
                  onChange={(e) =>
                    setPledgeTime(Number(e.target.value))
                  }
                  className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, rgb(251 191 36) 0%, rgb(251 191 36) ${((pledgeTime - 3600) / (259200 - 3600)) * 100}%, rgba(255,255,255,0.2) ${((pledgeTime - 3600) / (259200 - 3600)) * 100}%, rgba(255,255,255,0.2) 100%)`,
                  }}
                />
                <div className="flex justify-between text-xs text-white/50 mt-2">
                  <span>1 hour</span>
                  <span>3 days</span>
                </div>
              </div>

              {/* Save Button */}
              <Button
                onClick={handleSaveInfo}
                size="lg"
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-0"
              >
                Save Information
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Rolling Info - Above Buttons with Smaller Size */}
      {account && contractBalance && (
        <div className="max-w-sm mx-auto mb-2">
          <RollingInfo
            unlockTime={unlockTime}
            expectedReward={expectedReward}
          />
          <p className="text-center text-xs text-white/50 mt-2">
            ℹ️ Showing your current active stake
          </p>
        </div>
      )}

      <div className="grid gap-4">
        <Button
          onClick={connectWallet}
          disabled={
            isConnecting || !!account || !selectedSymbol
          }
          size="lg"
          className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white border-0 disabled:opacity-50"
        >
          <Wallet className="mr-2 h-5 w-5" />
          {isConnecting
            ? "Connecting..."
            : account
              ? "Wallet Connected"
              : "Step 2: Connect Wallet"}
        </Button>

        <Button
          onClick={() => setShowInfoModal(true)}
          disabled={!account}
          size="lg"
          className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white border-0 disabled:opacity-50"
        >
          <Info className="mr-2 h-5 w-5" />
          Set Your Commitment
        </Button>

        <Button
          onClick={stakeTokens}
          disabled={
            !account || !balanceAmount || !tokenAddress
          }
          size="lg"
          variant="outline"
          className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-0 disabled:opacity-50"
        >
          <Send className="mr-2 h-5 w-5" />
          Stake USDC & Lock Commitment
        </Button>
      </div>

      {/* Extract Button - Unique Styling at Bottom */}
      {account && contractBalance && (
        <div className="mt-8 pt-6 border-t-2 border-yellow-400/30">
          <Button
            onClick={extractRewards}
            disabled={!account || !contractBalance}
            size="lg"
            className="w-full bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-500 hover:from-yellow-500 hover:via-amber-600 hover:to-orange-600 text-gray-900 font-bold border-2 border-yellow-300/50 shadow-lg shadow-yellow-500/50 hover:shadow-xl hover:shadow-yellow-500/70 disabled:opacity-50 disabled:shadow-none transition-all duration-300 transform hover:scale-[1.02]"
          >
            <TrendingUp className="mr-2 h-6 w-6" />
            <span className="text-lg">Extract Rewards</span>
          </Button>
          <p className="text-center text-xs text-yellow-400/70 mt-3">
            ⚡ Withdraw your staked USDC + earned rewards
          </p>
        </div>
      )}
    </div>
  );
}