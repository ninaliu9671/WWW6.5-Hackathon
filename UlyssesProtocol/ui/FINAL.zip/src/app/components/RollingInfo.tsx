import { useState, useEffect } from "react";
import { Clock, TrendingUp } from "lucide-react";

interface RollingInfoProps {
  unlockTime?: number; // Unix timestamp
  expectedReward?: string;
}

export function RollingInfo({ unlockTime, expectedReward }: RollingInfoProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [remainingTime, setRemainingTime] = useState("");

  useEffect(() => {
    // Update remaining time every second
    const updateTime = () => {
      if (!unlockTime) {
        setRemainingTime("No active contract");
        return;
      }

      const now = Math.floor(Date.now() / 1000);
      const diff = unlockTime - now;

      if (diff <= 0) {
        setRemainingTime("Contract unlocked");
      } else {
        const days = Math.floor(diff / 86400);
        const hours = Math.floor((diff % 86400) / 3600);
        const minutes = Math.floor((diff % 3600) / 60);
        const seconds = diff % 60;

        if (days > 0) {
          setRemainingTime(`${days}d ${hours}h ${minutes}m ${seconds}s`);
        } else if (hours > 0) {
          setRemainingTime(`${hours}h ${minutes}m ${seconds}s`);
        } else if (minutes > 0) {
          setRemainingTime(`${minutes}m ${seconds}s`);
        } else {
          setRemainingTime(`${seconds}s`);
        }
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    return () => clearInterval(interval);
  }, [unlockTime]);

  useEffect(() => {
    // Rotate between different info every 3 seconds
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % 2);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const items = [
    {
      icon: Clock,
      label: "Remaining Time",
      value: remainingTime,
      color: "from-blue-400 to-cyan-400",
    },
    {
      icon: TrendingUp,
      label: "Expected Rewards",
      value: expectedReward || "0 USDC",
      color: "from-yellow-400 to-orange-400",
    },
  ];

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-yellow-400/20 max-w-lg mx-auto overflow-hidden">
      <div className="relative h-16">
        {items.map((item, index) => {
          const Icon = item.icon;
          const isActive = index === currentIndex;
          
          return (
            <div
              key={index}
              className={`absolute inset-0 transition-all duration-500 ${
                isActive
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-4"
              }`}
            >
              <div className="flex items-center justify-between h-full">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${item.color}`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-white/60">{item.label}</p>
                    <p className="text-lg font-semibold text-white">
                      {item.value}
                    </p>
                  </div>
                </div>
                {/* Progress indicator */}
                <div className="flex gap-1">
                  {items.map((_, i) => (
                    <div
                      key={i}
                      className={`w-2 h-2 rounded-full transition-all ${
                        i === currentIndex
                          ? "bg-yellow-400 w-4"
                          : "bg-white/30"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
