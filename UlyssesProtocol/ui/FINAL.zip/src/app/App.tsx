import { Toaster } from "./components/ui/sonner";
import { WalletConnection } from "./components/WalletConnection";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { RollingInfo } from "./components/RollingInfo";
import { useState, useEffect } from "react";

export default function App() {
  const [contractInfo, setContractInfo] = useState<{
    unlockTime?: number;
    expectedReward?: string;
  }>({});

  useEffect(() => {
    // Listen for contract info updates from WalletConnection
    const handleContractInfo = (event: any) => {
      setContractInfo(event.detail);
    };

    window.addEventListener("contractInfoUpdate", handleContractInfo);

    return () => {
      window.removeEventListener("contractInfoUpdate", handleContractInfo);
    };
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1623091673195-5129ee559372?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZHlzc2V1cyUyMHVseXNzZXMlMjBhbmNpZW50JTIwZ3JlZWslMjBteXRob2xvZ3l8ZW58MXx8fHwxNzc1MDQyMTEwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Ulysses Pact Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/80 via-purple-900/80 to-red-900/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-6">
        <div className="max-w-2xl w-full space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-block">
              <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">
                Ulysses
              </h1>
              <p className="text-xl md:text-2xl text-white/90 mt-2">
                Let us adhere to the Ulysses Contract
              </p>
            </div>
            <p className="text-white/70 max-w-md mx-auto leading-relaxed">
              Setting in place, while we are lucid, mandatory
              constraints to prevent ourselves from acting on
              impulse.
            </p>
          </div>

          {/* Wallet Connection Component */}
          <WalletConnection />

          {/* Footer Note */}
          <div className="text-center pt-4">
            <p className="text-xs text-white/50">
              Make sure you have MetaMask or a compatible Web3
              wallet installed
            </p>
          </div>
        </div>
      </div>

      {/* Slash Mechanism Link - Bottom Right */}
      <a
        href="http://localhost:3001/history"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-20 bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-red-400/30 hover:bg-white/20 hover:border-red-400/50 transition-all cursor-pointer group"
      >
        <div className="flex items-center gap-3">
          <div className="text-2xl">⚔️</div>
          <div>
            <h3 className="text-white font-semibold mb-1 group-hover:text-red-400 transition-colors">
              Slash Mechanism
            </h3>
            <p className="text-xs text-white/60">
              View watcher status →
            </p>
          </div>
        </div>
      </a>

      <Toaster position="bottom-right" />
    </div>
  );
}